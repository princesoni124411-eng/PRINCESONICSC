const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
// Using port 3456 as defined in your _superninja_startup.conf
const PORT = process.env.PORT || 3456; 
const DATA_FILE = path.join(__dirname, 'data.json');

// Middleware
app.use(cors()); // Allow requests from your frontend HTML
app.use(express.json({ limit: '10mb' })); // Allow large data payloads

// Default structure according to your CSC Management System
const defaultData = {
    recs: [],
    staff: [],
    actLog: [],
    adminPW: 'Prince@6864',
    billCtr: 10,
    lastUpdated: Date.now()
};

// --- Helper Functions ---

// Read data from local JSON file
const readData = () => {
    if (!fs.existsSync(DATA_FILE)) {
        // If file doesn't exist, create it with default data
        fs.writeFileSync(DATA_FILE, JSON.stringify(defaultData, null, 2));
        return defaultData;
    }
    try {
        const rawData = fs.readFileSync(DATA_FILE, 'utf-8');
        return JSON.parse(rawData);
    } catch (error) {
        console.error('Error reading data:', error);
        return defaultData;
    }
};

// Write data to local JSON file
const writeData = (data) => {
    try {
        // Update the timestamp
        data.lastUpdated = Date.now();
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return { success: true, timestamp: data.lastUpdated };
    } catch (error) {
        console.error('Error writing data:', error);
        return { success: false };
    }
};

// --- API Endpoints ---

// 1. GET Request: Fetch all data (Used when page loads)
app.get('/api/sync', (req, res) => {
    console.log(`[${new Date().toISOString()}] GET /api/sync - Fetching data...`);
    const data = readData();
    res.json(data);
});

// 2. POST Request: Save/Update all data (Used when data changes)
app.post('/api/sync', (req, res) => {
    console.log(`[${new Date().toISOString()}] POST /api/sync - Saving data...`);
    const newData = req.body;
    
    if (!newData || Object.keys(newData).length === 0) {
        return res.status(400).json({ error: 'No data provided in request body' });
    }
    
    // Merge existing data with new data to prevent missing fields
    const currentData = readData();
    const mergedData = { ...currentData, ...newData };
    
    const result = writeData(mergedData);
    
    if (result.success) {
        res.json({ message: 'Data synced successfully', lastUpdated: result.timestamp });
    } else {
        res.status(500).json({ error: 'Failed to save data on server' });
    }
});

// 3. Health Check: To verify server is running
app.get('/api/health', (req, res) => {
    res.json({ status: 'API is running perfectly!', port: PORT });
});

// Start the server
app.listen(PORT, () => {
    console.log(`========================================`);
    console.log(`🚀 CSC Sync Server API running on port ${PORT}`);
    console.log(`📂 Data will be saved in: ${DATA_FILE}`);
    console.log(`🌐 Endpoints:`);
    console.log(`   - GET  http://localhost:${PORT}/api/sync`);
    console.log(`   - POST http://localhost:${PORT}/api/sync`);
    console.log(`========================================`);
});