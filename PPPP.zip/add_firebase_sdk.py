with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Firebase SDK scripts add karo <head> mein
firebase_sdk = """<!-- Firebase SDK -->
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-database-compat.js"></script>
<script>
// ─── Firebase Configuration ───────────────────────
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyC_placeholder_key_replace_with_real",
  authDomain: "csc-prince-soni-default-rtdb.firebaseapp.com",
  databaseURL: "https://csc-prince-soni-default-rtdb.firebaseio.com",
  projectId: "csc-prince-soni",
  storageBucket: "csc-prince-soni.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:000000000000000000000000"
};
</script>
"""

# </head> se pehle add karo
if '</head>' in content:
    content = content.replace('</head>', firebase_sdk + '</head>', 1)
    print("✅ Firebase SDK added to <head>")
else:
    print("❌ </head> not found")

# 2. loadData() ke baad initFirebase() call karo
old_init = "loadData();\n\n// \u2550"
new_init = "loadData();\n// Firebase real-time sync start karo\nif(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',initFirebase);}else{initFirebase();}\n\n// \u2550"

if old_init in content:
    content = content.replace(old_init, new_init, 1)
    print("✅ initFirebase() call added after loadData()")
else:
    # try alternate
    idx = content.find("loadData();")
    print(f"loadData() found at index: {idx}")
    if idx != -1:
        content = content[:idx+len("loadData();")] + "\n// Firebase real-time sync start karo\nif(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',initFirebase);}else{initFirebase();}" + content[idx+len("loadData();"):]
        print("✅ initFirebase() call added (alternate method)")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("File saved successfully!")