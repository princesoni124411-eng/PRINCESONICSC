const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3456;
const DATA_FILE = path.join(__dirname, 'data.json');

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Default data
const DEFAULT_DATA = {
  recs: [],
  staff: [],
  actLog: [],
  adminPW: 'Prince@6864',
  billCtr: 10,
  lastUpdated: Date.now()
};

// Read data from file
function readData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf8');
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Read error:', e);
  }
  return DEFAULT_DATA;
}

// Write data to file
function writeData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('Write error:', e);
    return false;
  }
}

// Initialize data file
if (!fs.existsSync(DATA_FILE)) {
  writeData(DEFAULT_DATA);
}

// GET - data load karo
app.get('/api/data', (req, res) => {
  const data = readData();
  res.json({ success: true, data });
});

// POST - data save karo
app.post('/api/data', (req, res) => {
  const newData = req.body;
  if (!newData) return res.status(400).json({ success: false, error: 'No data' });
  newData.lastUpdated = Date.now();
  const ok = writeData(newData);
  res.json({ success: ok });
});

// GET - check last update time (polling ke liye)
app.get('/api/ping', (req, res) => {
  const data = readData();
  res.json({ lastUpdated: data.lastUpdated || 0 });
});

// Health check
app.get('/', (req, res) => {
  res.json({ status: 'CSC Sync Server Running ✅', time: new Date().toISOString() });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ CSC Sync Server running on port ${PORT}`);
});