with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# JSONBlob ID
BLOB_ID = "019d06bc-d019-72ae-9df2-5963c39b4969"
BLOB_URL = f"https://jsonblob.com/api/jsonBlob/{BLOB_ID}"

# Firebase SDK scripts hata do
import re

# Remove Firebase SDK scripts from head
content = re.sub(r'<!-- Firebase SDK -->.*?</script>\s*', '', content, flags=re.DOTALL)
print("✅ Firebase SDK removed")

# Purana Firebase + localStorage code dhundo aur replace karo
# lsGet se lekar loadData() tak
old_pattern_start = "// ─── localStorage helpers (offline fallback) ───────"
old_pattern_end = "// ─── Firebase sync ──────────────────────────────────"

start_idx = content.find(old_pattern_start)
# Find end of loadData function
load_data_end = content.find("}\n\n// ─── All variables declared FIRST", start_idx)
if load_data_end == -1:
    load_data_end = content.find("}\n\n// ══", start_idx + 100)

print(f"Start idx: {start_idx}, End idx: {load_data_end}")

if start_idx != -1 and load_data_end != -1:
    old_block = content[start_idx:load_data_end+1]
    print(f"Block length: {len(old_block)}")
    
    new_block = f"""// ─── localStorage helpers (offline fallback) ───────
function lsGet(key,def){{
  try{{const v=localStorage.getItem('csc_'+key);return v?JSON.parse(v):def;}}
  catch(e){{return def;}}
}}
function lsSet(key,val){{
  try{{localStorage.setItem('csc_'+key,JSON.stringify(val));}}
  catch(e){{console.warn('Storage full',e);}}
}}

// ─── JSONBlob Sync (Cross-Device) ─────────────────────
const SYNC_URL = "{BLOB_URL}";
let syncTimeout = null;
let lastSyncTime = 0;
let isSyncing = false;
let pollInterval = null;

function updateSyncStatus(state, msg){{
  const el = document.getElementById('syncStatus');
  const tx = document.getElementById('syncTxt');
  if(!el||!tx) return;
  el.className = 'sync-status ' + state;
  tx.textContent = msg;
}}

function saveLocal(){{
  lsSet('recs',recs); lsSet('staff',staffList);
  lsSet('actLog',actLog); lsSet('adminPW',adminPW); lsSet('billCtr',billCtr);
}}

function saveData(){{
  saveLocal();
  pushToCloud();
}}

function pushToCloud(){{
  if(isSyncing) return;
  clearTimeout(syncTimeout);
  syncTimeout = setTimeout(()=>{{
    isSyncing = true;
    updateSyncStatus('syncing','🔄 Sync ho raha hai...');
    const payload = JSON.stringify({{recs, staff:staffList, actLog, adminPW, billCtr, lastUpdated: Date.now()}});
    fetch(SYNC_URL, {{
      method: 'PUT',
      headers: {{'Content-Type': 'application/json'}},
      body: payload
    }})
    .then(r => r.json())
    .then(d => {{
      isSyncing = false;
      lastSyncTime = Date.now();
      saveLocal();
      updateSyncStatus('online','☁️ Synced ✓');
    }})
    .catch(e => {{
      isSyncing = false;
      console.warn('Sync failed:', e);
      updateSyncStatus('offline','❌ Sync Failed');
    }});
  }}, 1000);
}}

function pullFromCloud(callback){{
  fetch(SYNC_URL)
  .then(r => r.json())
  .then(d => {{
    if(!d) return;
    recs       = d.recs      || [];
    staffList  = d.staff     || SAMPLE_STAFF;
    actLog     = d.actLog    || [];
    adminPW    = d.adminPW   || 'Prince@6864';
    billCtr    = d.billCtr   || 10;
    lastSyncTime = d.lastUpdated || Date.now();
    saveLocal();
    updateSyncStatus('online','☁️ Connected ✓');
    if(callback) callback();
    const appEl = document.getElementById('app');
    if(appEl && appEl.style.display !== 'none'){{
      renderAll(); updateBadge();
    }}
  }})
  .catch(e => {{
    console.warn('Pull failed, using local data:', e);
    updateSyncStatus('offline','📱 Offline Mode');
  }});
}}

// Har 10 second mein cloud se check karo (polling)
function startPolling(){{
  if(pollInterval) clearInterval(pollInterval);
  pollInterval = setInterval(()=>{{
    fetch(SYNC_URL)
    .then(r => r.json())
    .then(d => {{
      if(d && d.lastUpdated && d.lastUpdated > lastSyncTime + 2000){{
        // Koi doosra device ne data update kiya - sync karo
        recs       = d.recs      || recs;
        staffList  = d.staff     || staffList;
        actLog     = d.actLog    || actLog;
        adminPW    = d.adminPW   || adminPW;
        billCtr    = d.billCtr   || billCtr;
        lastSyncTime = d.lastUpdated;
        saveLocal();
        updateSyncStatus('online','☁️ Synced ✓');
        const appEl = document.getElementById('app');
        if(appEl && appEl.style.display !== 'none'){{
          renderAll(); updateBadge();
          toast('🔄 Data sync hua!', 'ok');
        }}
      }}
    }})
    .catch(()=>{{}});
  }}, 10000);
}}

function loadData(){{
  // Pehle localStorage se load karo (instant)
  recs      = lsGet('recs',     SAMPLE_RECS);
  staffList = lsGet('staff',    SAMPLE_STAFF);
  actLog    = lsGet('actLog',   []);
  adminPW   = lsGet('adminPW',  'Prince@6864');
  billCtr   = lsGet('billCtr',  10);
  // Phir cloud se latest data fetch karo
  pullFromCloud(()=>{{ startPolling(); }});
}}"""
    
    content = content[:start_idx] + new_block + content[load_data_end+1:]
    print("✅ Sync code replaced successfully!")
else:
    print(f"❌ Could not find block. Searching manually...")
    # Manual search
    idx1 = content.find("function lsGet")
    idx2 = content.find("function loadData")
    idx3 = content.find("}", idx2)
    print(f"lsGet: {idx1}, loadData: {idx2}, end: {idx3}")

# Firebase setup modal bhi hata do (ab zarurat nahi)
content = re.sub(r'<!-- Firebase Setup Modal -->.*?</script>\s*', '', content, flags=re.DOTALL)
print("✅ Firebase setup modal removed")

# initFirebase calls remove karo
content = content.replace("// Firebase real-time sync start karo\nif(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',initFirebase);}else{initFirebase();}\n", "")
print("✅ initFirebase calls removed")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)
print("\n✅ All done! File saved.")