with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Firebase Setup Modal HTML add karo - </body> se pehle
firebase_modal = """
<!-- Firebase Setup Modal -->
<div id="fbSetupModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;">
  <div style="background:#fff;border-radius:20px;padding:28px;max-width:500px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 24px 80px rgba(0,0,0,.4);">
    <div style="text-align:center;margin-bottom:20px;">
      <div style="font-size:40px;margin-bottom:8px;">☁️</div>
      <h2 style="font-size:20px;font-weight:800;color:#1a3a6e;">Firebase Setup - Cross-Device Sync</h2>
      <p style="color:#64748b;font-size:13px;margin-top:6px;">Mobile aur PC dono mein same data dikhane ke liye</p>
    </div>
    
    <div style="background:#eef2ff;border-radius:12px;padding:16px;margin-bottom:16px;">
      <p style="font-size:13px;font-weight:700;color:#1a3a6e;margin-bottom:10px;">📋 Step 1: Firebase Project Banayein (FREE)</p>
      <ol style="font-size:13px;color:#334155;line-height:2;padding-left:18px;">
        <li><a href="https://console.firebase.google.com" target="_blank" style="color:#2356b8;font-weight:600;">console.firebase.google.com</a> kholo</li>
        <li>"Add project" click karo</li>
        <li>Project name: <b>csc-prince-soni</b></li>
        <li>Google Analytics: OFF kar do → Create</li>
        <li>Left menu mein "Realtime Database" click karo</li>
        <li>"Create Database" → "Start in test mode" → Enable</li>
      </ol>
    </div>
    
    <div style="background:#eef2ff;border-radius:12px;padding:16px;margin-bottom:16px;">
      <p style="font-size:13px;font-weight:700;color:#1a3a6e;margin-bottom:10px;">📋 Step 2: Config Copy Karein</p>
      <ol style="font-size:13px;color:#334155;line-height:2;padding-left:18px;">
        <li>Project Settings (⚙️) → "Your apps" → Web app (</>)</li>
        <li>App nickname: "CSC App" → Register</li>
        <li>firebaseConfig object ko copy karo</li>
      </ol>
    </div>
    
    <div style="background:#fff7ed;border-radius:12px;padding:16px;margin-bottom:16px;">
      <p style="font-size:13px;font-weight:700;color:#c2410c;margin-bottom:10px;">🔑 Step 3: Config Yahan Paste Karein</p>
      <textarea id="fbConfigInput" style="width:100%;height:120px;border:2px solid #fed7aa;border-radius:8px;padding:10px;font-family:monospace;font-size:11px;resize:vertical;" placeholder='Yahan firebaseConfig paste karein, example:
{
  apiKey: "AIzaSy...",
  authDomain: "your-app.firebaseapp.com",
  databaseURL: "https://your-app-default-rtdb.firebaseio.com",
  projectId: "your-app",
  ...
}'></textarea>
      <button onclick="applyFirebaseConfig()" style="width:100%;margin-top:10px;padding:12px;background:linear-gradient(135deg,#1a3a6e,#2356b8);color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:800;cursor:pointer;">✅ Save & Connect</button>
    </div>
    
    <div style="text-align:center;">
      <button onclick="document.getElementById('fbSetupModal').style.display='none'" style="background:none;border:none;color:#64748b;font-size:13px;cursor:pointer;text-decoration:underline;">Baad mein karenge (Local mode mein chalao)</button>
    </div>
  </div>
</div>

<script>
// ─── Firebase Config Apply ───────────────────────────
function applyFirebaseConfig(){
  const txt = document.getElementById('fbConfigInput').value.trim();
  if(!txt){ alert('Config paste karo pehle!'); return; }
  try {
    // Config text se object extract karo
    let configStr = txt;
    // Agar const firebaseConfig = { ... }; format mein hai
    const match = txt.match(/\{[\s\S]*\}/);
    if(!match){ alert('Valid config nahi mili! Dobara copy karo.'); return; }
    // Eval se object banao (safe - user ka apna config hai)
    const cfg = Function('return (' + match[0] + ')')();
    if(!cfg.apiKey || !cfg.databaseURL){ alert('apiKey ya databaseURL missing hai!'); return; }
    // Save to localStorage
    localStorage.setItem('csc_firebase_config', JSON.stringify(cfg));
    window.FIREBASE_CONFIG = cfg;
    // Re-initialize Firebase
    fbReady = false; fbDB = null; fbListenerActive = false;
    initFirebase();
    document.getElementById('fbSetupModal').style.display='none';
    // Show success
    setTimeout(()=>{ 
      if(fbReady) toast('🎉 Firebase Connected! Ab sab devices mein sync hoga!','ok');
      else toast('❌ Config galat hai, dobara check karo','err');
    }, 1500);
  } catch(e) {
    alert('Config mein error: ' + e.message);
  }
}

// ─── Saved config load karo ─────────────────────────
(function(){
  const saved = localStorage.getItem('csc_firebase_config');
  if(saved){
    try {
      window.FIREBASE_CONFIG = JSON.parse(saved);
      console.log('✅ Saved Firebase config loaded');
    } catch(e) {}
  }
})();

// ─── Setup button sync status mein ─────────────────
function showFbSetup(){
  document.getElementById('fbSetupModal').style.display='flex';
}
</script>
"""

# </body> se pehle add karo
if '</body>' in content:
    content = content.replace('</body>', firebase_modal + '\n</body>', 1)
    print("✅ Firebase Setup Modal added")
else:
    print("❌ </body> not found")

# syncTxt click karne par setup modal khule (agar not configured)
old_sync_click = '<div id="syncStatus" class="sync-status offline">\n    <div class="sync-dot"></div>\n    <span id="syncTxt">⚠️ Setup Firebase</span>\n  </div>'
new_sync_click = '<div id="syncStatus" class="sync-status offline" onclick="if(!fbReady)showFbSetup()" style="cursor:pointer;" title="Click to setup Firebase sync">\n    <div class="sync-dot"></div>\n    <span id="syncTxt">⚠️ Setup Firebase</span>\n  </div>'
content = content.replace(old_sync_click, new_sync_click, 1)
print("✅ Sync status clickable made")

# initFirebase mein saved config use karo
old_init_check = "  try {\n    if(typeof firebase === 'undefined'){ fbReady=false; return; }\n    if(!firebase.apps.length) firebase.initializeApp(window.FIREBASE_CONFIG);"
new_init_check = """  try {
    if(typeof firebase === 'undefined'){ fbReady=false; return; }
    // Saved config check karo
    const saved = localStorage.getItem('csc_firebase_config');
    if(saved && !window.FIREBASE_CONFIG_LOADED){
      try{ window.FIREBASE_CONFIG = JSON.parse(saved); window.FIREBASE_CONFIG_LOADED=true; }catch(e){}
    }
    if(!window.FIREBASE_CONFIG || window.FIREBASE_CONFIG.apiKey.includes('placeholder')){ 
      fbReady=false; 
      setTimeout(()=>updateSyncStatus('offline','⚙️ Setup Firebase ↑'),500);
      return; 
    }
    if(!firebase.apps.length) firebase.initializeApp(window.FIREBASE_CONFIG);"""

content = content.replace(old_init_check, new_init_check, 1)
print("✅ initFirebase updated with saved config check")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)
print("\n✅ All done! File saved.")