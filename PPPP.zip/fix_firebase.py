import re

with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Find the exact localStorage section
old_code = """function lsGet(key,def){
  try{const v=localStorage.getItem('csc_'+key);return v?JSON.parse(v):def;}
  catch(e){return def;}
}
function lsSet(key,val){
  try{localStorage.setItem('csc_'+key,JSON.stringify(val));}
  catch(e){console.warn('Storage full',e);}
}
function saveData(){
  lsSet('recs',recs);
  lsSet('staff',staffList);
  lsSet('actLog',actLog);
  lsSet('adminPW',adminPW);
  lsSet('billCtr',billCtr);
}
function loadData(){
  recs      = lsGet('recs',     SAMPLE_RECS);
  staffList = lsGet('staff',    SAMPLE_STAFF);
  actLog    = lsGet('actLog',   []);
  adminPW   = lsGet('adminPW',  'Prince@6864');
  billCtr   = lsGet('billCtr',  10);
}"""

new_code = """// ─── localStorage helpers (offline fallback) ───────
function lsGet(key,def){
  try{const v=localStorage.getItem('csc_'+key);return v?JSON.parse(v):def;}
  catch(e){return def;}
}
function lsSet(key,val){
  try{localStorage.setItem('csc_'+key,JSON.stringify(val));}
  catch(e){console.warn('Storage full',e);}
}

// ─── Firebase sync ──────────────────────────────────
let fbDB = null;
let fbReady = false;
let syncTimeout = null;
let fbListenerActive = false;

function initFirebase(){
  try {
    if(typeof firebase === 'undefined'){ fbReady=false; return; }
    if(!firebase.apps.length) firebase.initializeApp(window.FIREBASE_CONFIG);
    fbDB = firebase.database();
    fbReady = true;
    console.log('✅ Firebase connected - Real-time sync active');
    if(fbListenerActive) return;
    fbListenerActive = true;
    // Real-time listener - jab bhi koi device data change kare, sabko milega
    fbDB.ref('cscData').on('value', snap => {
      const d = snap.val();
      if(!d){ saveToFirebase(); return; }
      recs      = d.recs      || SAMPLE_RECS;
      staffList = d.staff     || SAMPLE_STAFF;
      actLog    = d.actLog    || [];
      adminPW   = d.adminPW   || 'Prince@6864';
      billCtr   = d.billCtr   || 10;
      lsSet('recs',recs); lsSet('staff',staffList);
      lsSet('actLog',actLog); lsSet('adminPW',adminPW); lsSet('billCtr',billCtr);
      const appEl = document.getElementById('app');
      if(appEl && appEl.style.display !== 'none'){
        renderAll(); updateBadge();
      }
    });
  } catch(e) {
    console.warn('Firebase init failed, using localStorage:', e);
    fbReady = false;
  }
}

function saveToFirebase(){
  if(!fbReady || !fbDB){ saveLocal(); return; }
  clearTimeout(syncTimeout);
  syncTimeout = setTimeout(()=>{
    fbDB.ref('cscData').set({
      recs, staff: staffList, actLog, adminPW, billCtr,
      lastUpdated: Date.now()
    }).then(()=>{ saveLocal(); })
    .catch(e=>{ console.warn('Firebase save failed:', e); saveLocal(); });
  }, 800);
}

function saveLocal(){
  lsSet('recs',recs); lsSet('staff',staffList);
  lsSet('actLog',actLog); lsSet('adminPW',adminPW); lsSet('billCtr',billCtr);
}

function saveData(){
  saveLocal();
  saveToFirebase();
}

function loadData(){
  recs      = lsGet('recs',     SAMPLE_RECS);
  staffList = lsGet('staff',    SAMPLE_STAFF);
  actLog    = lsGet('actLog',   []);
  adminPW   = lsGet('adminPW',  'Prince@6864');
  billCtr   = lsGet('billCtr',  10);
}"""

if old_code in content:
    content = content.replace(old_code, new_code)
    print("✅ localStorage section replaced successfully!")
else:
    print("❌ String not found - checking...")
    # Try to find partial match
    idx = content.find("function lsGet(key,def){")
    print(f"lsGet found at index: {idx}")
    idx2 = content.find("function saveData(){")
    print(f"saveData found at index: {idx2}")
    idx3 = content.find("function loadData(){")
    print(f"loadData found at index: {idx3}")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("File saved.")