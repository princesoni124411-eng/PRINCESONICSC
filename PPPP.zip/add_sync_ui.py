with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Sync status HTML sidebar footer mein add karo
old_sfoot = '<div class="s-foot">'
new_sfoot = '''<div class="s-foot">
  <div id="syncStatus" class="sync-status offline">
    <div class="sync-dot"></div>
    <span id="syncTxt">⚠️ Setup Firebase</span>
  </div>'''

content = content.replace(old_sfoot, new_sfoot, 1)
print("✅ Sync status UI added to sidebar")

# 2. updateSyncStatus function add karo - saveToFirebase ke baad
old_func = "function saveData(){"
new_func = """function updateSyncStatus(state, msg){
  const el = document.getElementById('syncStatus');
  const tx = document.getElementById('syncTxt');
  if(!el||!tx) return;
  el.className = 'sync-status ' + state;
  tx.textContent = msg;
}

function saveData(){"""

content = content.replace(old_func, new_func, 1)
print("✅ updateSyncStatus function added")

# 3. saveToFirebase mein status update karo
old_save = """function saveToFirebase(){
  if(!fbReady || !fbDB){ saveLocal(); return; }
  clearTimeout(syncTimeout);
  syncTimeout = setTimeout(()=>{
    fbDB.ref('cscData').set({
      recs, staff: staffList, actLog, adminPW, billCtr,
      lastUpdated: Date.now()
    }).then(()=>{ saveLocal(); })
    .catch(e=>{ console.warn('Firebase save failed:', e); saveLocal(); });
  }, 800);
}"""

new_save = """function saveToFirebase(){
  if(!fbReady || !fbDB){ saveLocal(); updateSyncStatus('offline','📴 Offline Mode'); return; }
  updateSyncStatus('syncing','🔄 Syncing...');
  clearTimeout(syncTimeout);
  syncTimeout = setTimeout(()=>{
    fbDB.ref('cscData').set({
      recs, staff: staffList, actLog, adminPW, billCtr,
      lastUpdated: Date.now()
    }).then(()=>{ saveLocal(); updateSyncStatus('online','☁️ Synced ✓'); })
    .catch(e=>{ console.warn('Firebase save failed:', e); saveLocal(); updateSyncStatus('offline','❌ Sync Failed'); });
  }, 800);
}"""

content = content.replace(old_save, new_save, 1)
print("✅ Sync status in saveToFirebase updated")

# 4. initFirebase mein bhi status update karo
old_init_fb = "    fbReady = true;\n    console.log('✅ Firebase connected - Real-time sync active');"
new_init_fb = "    fbReady = true;\n    console.log('✅ Firebase connected - Real-time sync active');\n    updateSyncStatus('online','☁️ Connected ✓');"
content = content.replace(old_init_fb, new_init_fb, 1)
print("✅ initFirebase status update added")

old_fail = "    console.warn('Firebase init failed, using localStorage:', e);\n    fbReady = false;"
new_fail = "    console.warn('Firebase init failed, using localStorage:', e);\n    fbReady = false;\n    updateSyncStatus('offline','📱 Local Only');"
content = content.replace(old_fail, new_fail, 1)
print("✅ Firebase fail status added")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)
print("\n✅ All UI updates done! File saved.")