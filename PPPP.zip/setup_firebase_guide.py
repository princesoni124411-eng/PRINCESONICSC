with open('/workspace/csc-website/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Firebase config ko ek user-friendly setup notice ke saath replace karo
# Pehle check karo ki FIREBASE_CONFIG sahi jagah hai
idx = content.find('window.FIREBASE_CONFIG')
print(f"FIREBASE_CONFIG found at: {idx}")

# Ab ek sync status indicator add karo - sidebar mein
old_sfoot = 's-foot{padding:14px 12px;border-top:1px solid rgba(255,255,255,.07)}'
print(f"s-foot found: {old_sfoot in content}")

# Sync indicator CSS add karo
sync_css = """
.sync-status{display:flex;align-items:center;gap:6px;padding:7px 10px;border-radius:8px;font-size:11px;font-weight:700;margin-bottom:8px;transition:all .3s}
.sync-status.online{background:rgba(16,185,129,.15);color:#6ee7b7;}
.sync-status.offline{background:rgba(239,68,68,.12);color:#fca5a5;}
.sync-status.syncing{background:rgba(245,158,11,.12);color:#fcd34d;}
.sync-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;}
.sync-status.online .sync-dot{background:#10b981;}
.sync-status.offline .sync-dot{background:#ef4444;}
.sync-status.syncing .sync-dot{background:#f59e0b;animation:spin .8s linear infinite;}
"""

# CSS ke end mein add karo (</style> se pehle)
if '</style>' in content:
    content = content.replace('</style>', sync_css + '</style>', 1)
    print("✅ Sync CSS added")

with open('/workspace/csc-website/index.html', 'w', encoding='utf-8') as f:
    f.write(content)
print("Done!")